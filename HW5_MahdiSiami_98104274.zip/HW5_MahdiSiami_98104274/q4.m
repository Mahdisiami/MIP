clc; 
close all; 
clear all;
hs = imread('Healthy_sample\00.png');
figure
imshow(hs)
title('Healthy Image');
%{
a = niftiread('Healthy_sample\00_mask.nii');
figure
for i = 1 : 266
    imagesc(a(: , : , i))
    title(strcat("Healthy Image: ",num2str(i)));
    pause(0.05)
end
%}

figure
a = niftiread('S03\pat3.nii');
imagesc(a(: , : , 100))
title(strcat("Patient 3 Image: ",num2str(100)));

figure
b = niftiread('S03\pat3_label.nii');
imagesc(b(: , : , 100))
title(strcat("Patient 3 Image label: ",num2str(100)));

% خواندن تصاویر ناحیه بندی شده FMRI
%path = 'path/to/segmentation/images'; % مسیر فایل‌های تصاویر ناحیه بندی شده FMRI
imageFiles = b; % خواندن تمام فایل‌های تصویر
numImages = length(imageFiles);

% تبدیل هر تصویر به point cloud
for i = 1:numImages
    % خواندن تصویر
    image = b;
    %image = image.img; % ماتریس تصویر

    % استخراج موقعیت نقاط (point) با توجه به ناحیه بندی
    [rows, cols, slices] = size(image);
    points = [];
    for z = 1:slices
        for y = 1:cols
            for x = 1:rows
                if image(x, y, z) ~= 0 % بررسی نقطه در ناحیه بندی
                    points = [points; x, y, z];
                end
            end
        end
    end

    % نمایش point cloud
    figure;
    scatter3(points(:,1), points(:,2), points(:,3), '.');
    title(['Point Cloud ', num2str(i)]);
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    axis equal;
end