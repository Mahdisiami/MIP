clc; 
close all; 
clear all;

% خواندن تصویر ورودی
image = imread('q2.png');

% تبدیل تصویر به تصویر خاکستری در صورت لزوم
if size(image, 3) == 3
    grayImage = rgb2gray(image);
else
    grayImage = image;
end

% تعیین جهت و گام
direction = 0; % جهت 0 در افقی (سمت چپ به راست)
step = 1; % گام 1 پیکسل

% ساخت ماتریس GLCM
glcm = graycomatrix(grayImage, 'Offset', [0 step], 'GrayLimits', [], 'NumLevels', 256, 'Symmetric', true);

% محاسبه ویژگی‌ها از ماتریس GLCM
stats = graycoprops(glcm, {'Contrast', 'Dissimilarity', 'Homogeneity', 'Entropy', 'Correlation'});

% استخراج مقادیر ویژگی‌ها
contrast = stats.Contrast;
dissimilarity = stats.Dissimilarity;
homogeneity = stats.Homogeneity;
entropy = entropy(glcm); % جایگزینی انتروپی به جای انرژی
correlation = stats.Correlation;

% نمایش مقادیر ویژگی‌ها
fprintf('Contrast: %f\n', contrast);
fprintf('Dissimilarity: %f\n', dissimilarity);
fprintf('Homogeneity: %f\n', homogeneity);
fprintf('Entropy: %f\n', entropy);
fprintf('Correlation: %f\n', correlation);

% نمایش ماتریس GLCM
figure;
imagesc(glcm);
colormap gray;
colorbar;