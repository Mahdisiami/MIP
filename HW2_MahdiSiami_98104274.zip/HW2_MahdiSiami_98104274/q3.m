% HW1 Mahdi Siami 98104274

%% q3
clc; 
clear all; 
close all;

P = phantom('Modified Shepp-Logan',500);
figure
imshow(P)
title("Original Image")

J = imnoise(P,'gaussian',0,0.3);
figure
imshow(J)
title("Noised Image")

hx = 1;
    
[x, y] = size(J);
denoised = zeros(x, y);
for i = 1 : x
    for j = 1 : y
        weights = zeros(x, y);
        for img = 1 : x
            for k = 1 : y
                weights(img, k) = exp(-((i - img)^2+(j - k)^2)/(2 * hx^2));
            end
        end
       denoised = reshape(denoised,[x,y]);
       denoised(i, j) = sum(double(denoised).*double(weights), 'all')/sum(double(weights), 'all');
       
    end
end

figure
imshow(denoised)
title('Denoised Image with hx = 1')