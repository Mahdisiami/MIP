clc; 
close all; 
clear all;
% 2.1
datafile = load('Part2\data\data.mat');
data = datafile.imageData;
mask = datafile.imageMask;

figure
imshow(data);
figure
imshow(mask);

mask = single(mask);
img = single(data);

% 2.2
[R, C] = size(mask);
k = 3;
q = 5;
bcon = 1;
binit = bcon.*ones(R,C).*mask;
f0 = 9;
sigmakernel = 2.5;

f = fspecial('gaussian', f0, sigmakernel);

% 2.3
eps = 10^(-7);

[seg, mu, sigma] = KMeans(data, mask, k, eps);

path = 'kmeans';
title_str = 'K-Means Output';
figure
showSegmented(seg, k, title_str, path);
 
% ////////// algorithm

u = zeros(R, C, k);           
for i = 1 : k
    u(:, :, i) = (seg == i);
end

b = binit;       
c = mu;           
w = f;  

J_init = objectiveFunction(img, b, c, q, u, w);    

epsn = 10^(-5);


%N_max = 50;
%N_max = 100;
%N_max = 150;

N_max = 200;

[u, b, c, J] = iterate(img, mask, u, b, c, q, w, J_init, epsn, N_max);
biasremoved = mask .* img ./ b;

figure
plot(1 : N_max, J);
title('Objective Function (Iter(N-max)= 200)');

figure
imshow(b)
title('Bias Field');

figure
imshow(img);
title('Corrupted Image');

figure
imshow(biasremoved);
title('Bias Removed Image');

figure
showSegmented(seg, k, 'Initial Image: Using K-Means', 'IIUK');

figure
showSegmented(u, 1, 'Segmented Image', 'SI');