clc; 
close all; 
clear all;

image = imread('melanoma.jpg');
gray = rgb2gray(image);
thresh_image = gray;
thresh_image = imgaussfilt(thresh_image, 5);
thresh = graythresh(thresh_image);
thresh_image = imbinarize(thresh_image, thresh);
image_gradient = get_gradient(thresh_image);

n_iter = 300;
init_points = initialize_points(size(image), [100, 70], [90, 80], 180);
points = active_contour(image, thresh_image, init_points, 1e-4, 1e9, 5, n_iter);
save_video('results', n_iter);


% ////////// func

function gradient = get_gradient(img)
    threshold1 = 150;
    threshold2 = 250;
    img = im2double(img);
    gradient = edge(img, 'Canny', [threshold1, threshold2]);
    gradient = imgaussfilt(gradient, 7);
    gradient = gradient / max(gradient(:));
end

function points = initialize_points(img_shape, center, radius, n_points)
    height = img_shape(1);
    width = img_shape(2);
    theta = linspace(0, 2*pi, n_points);
    x_points = center(1) + round(radius(1) * cos(theta));
    x_points(x_points < 1) = 1;
    x_points(x_points > width) = width;
    y_points = center(2) + round(radius(2) * sin(theta));
    y_points(y_points < 1) = 1;
    y_points(y_points > height) = height;
    points = [x_points; y_points]';
end

function [E_total, E_internal, E_external] = total_energy(image, image_gradient, points, alpha, lambda_)
    points = [points; points(1, :)];
    dxdy = diff(points, 1).^2;
    elasticity = dxdy(:, 1) + dxdy(:, 2);
    d = mean(sqrt(elasticity));
    E_internal = mean((elasticity - alpha * d).^2);
    G = image_gradient(sub2ind(size(image_gradient), points(:, 2), points(:, 1)));
    E_external = -sum(G);
    E_total = E_internal + lambda_ * E_external;
end

function new_points = update_points(gray, image_gradient, points, alpha, lambda_, kernel_size)
    margin = floor(kernel_size / 2);
    [height, width] = size(gray);
    [E_total, ~, ~] = total_energy(gray, image_gradient, points, alpha, lambda_);
    new_points = points;
    temp_points = points;
    for i = 1:size(points, 1)
        x_start = max(points(i, 1) - margin, 1);
        x_end = min(points(i, 1) + margin, width);
        y_start = max(points(i, 2) - margin, 1);
        y_end = min(points(i, 2) + margin, height);

        E_total_copy = E_total;
        for x = x_start:x_end
            for y = y_start:y_end
                temp_points(i, :) = [x, y];
                [new_E_total, ~, ~] = total_energy(gray, image_gradient, temp_points, alpha, lambda_);
                if new_E_total < E_total_copy
                    new_points(i, :) = [x, y];
                    E_total_copy = new_E_total;
                end
            end
        end
        temp_points(i, :) = points(i, :);
    end
end

function save_image(image, points, path, name)
    image_copy = im2uint8(image);
    points = [points; points(1, :)];
    for i = 1:size(points, 1)-1
        image_copy = insertShape(image_copy, 'Line', [points(i, :), points(i+1, :)], 'Color', 'green', 'LineWidth', 1);
    end
    imwrite(image_copy, fullfile(path, [name, '.jpg']));
end

function points = active_contour(image, gray, init_points, alpha, lambda_, kernel_size, n_iter)
    image_gradient = get_gradient(gray);
    points = init_points;

    path = 'results';
    for iter = 1:n_iter
        points = update_points(gray, image_gradient, points, alpha, lambda_, kernel_size);
        save_image(image, points, path, num2str(iter-1));
    end
    points = [points; points(1, :)];
end

function save_video(path, n_frames)
    img = cell(1, n_frames);
    for i = 1:n_frames
        img{i} = imread(fullfile(path, [num2str(i-1), '.jpg']));
    end
    [h, w, ~] = size(img{1});
    video = VideoWriter('segmentation.mp4', 'MPEG-4');
    video.FrameRate = 5;
    open(video);
    for j = 1:n_frames
        writeVideo(video, img{j});
    end
    close(video);
end